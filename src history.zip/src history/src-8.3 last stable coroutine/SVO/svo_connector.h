#ifndef SVO_CONNECTOR_H
#define SVO_CONNECTOR_H

#include <godot_cpp/godot.hpp>
#include <godot_cpp/classes/node.hpp>
#include <godot_cpp/templates/vector.hpp>

#include <godot_cpp/variant/vector3.hpp>
#include <godot_cpp/classes/mesh_instance3d.hpp>

namespace godot {


}

#endif // SVO_CONNECTOR_H