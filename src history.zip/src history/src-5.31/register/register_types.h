#pragma once
void initialize_svo_module();
void uninitialize_svo_module();
